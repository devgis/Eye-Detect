﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Yaml.Grammar
{
    public partial class YamlVersion
    {
        public string Major;

        public string Minor;

    }
}
