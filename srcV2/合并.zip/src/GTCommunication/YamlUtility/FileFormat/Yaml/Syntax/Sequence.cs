﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Yaml.Grammar
{
    public partial class Sequence : DataItem
    {
        public List<DataItem> Enties = new List<DataItem>();

    }
}
