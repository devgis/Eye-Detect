﻿namespace GazeTrackerUI.CalibrationUI
{
    public partial class VisualGazePoint
    {
        public VisualGazePoint()
        {
            InitializeComponent();

            // Insert code required on object creation below this point.
        }
    }
}