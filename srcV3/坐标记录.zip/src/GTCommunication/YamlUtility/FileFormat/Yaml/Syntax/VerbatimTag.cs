﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QiHe.Yaml.Grammar
{
    public partial class VerbatimTag : Tag
    {
        public List<char> Chars = new List<char>();

    }
}
