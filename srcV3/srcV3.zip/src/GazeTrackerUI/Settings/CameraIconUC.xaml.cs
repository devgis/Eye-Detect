﻿using System.Windows.Controls;

namespace GazeTrackerUI.SettingsUI
{
	public partial class CameraIconUC : UserControl
	{
		public CameraIconUC()
		{
			this.InitializeComponent();
		}
	}
}